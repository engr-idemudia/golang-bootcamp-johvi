package piscine

func NRune(s string, n int) rune {
	x := []rune(s) // turns the string given into an array of runes
	// if length of x < n || n <= 0
	if len(x) < n || n <= 0 {
		// returns 0
		return 0
	}
	// return x[n-1] the nth value is -1
	return x[n-1]
}
