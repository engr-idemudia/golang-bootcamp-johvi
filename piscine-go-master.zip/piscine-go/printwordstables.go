package piscine

import (
	"github.com/01-edu/z01"
)

func PrintWordsTables(a []string) {
	aString := ConcatParams(a)
	for i := 0; i < len(aString); i++ {
		z01.PrintRune(rune(aString[i]))
	}
	z01.PrintRune('\n')
}
