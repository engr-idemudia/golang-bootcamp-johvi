package main

import (
	"piscine"

	"github.com/01-edu/z01"
)

func main() {
	piscine.PrintNbr(-123)
	piscine.PrintNbr(0)
	piscine.PrintNbr(123)
	z01.PrintRune('\n')
}

// possible output
//$ go run .
// -1230123
// $
