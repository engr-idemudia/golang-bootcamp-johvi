package piscine

func AtoiBase(s string, base string) int {
	eachdigit := true
	for i := 0; i < len(base); i++ {
		for j := i + 1; j < len(base); j++ {
			if base[i] == base[j] || base[i] == '+' || base[i] == '-' {
				eachdigit = false
			}
		}
	}
	if !eachdigit || len(base) < 2 {
		return 0
	}
	value := 0
	bSize := len(base)
	sSize := len(s)
	for i := 0; i < sSize; i++ {
		calc := 1
		for j := 0; j < sSize-i-1; j++ {
			calc *= bSize
		}
		value += Index(base, string(rune(s[i]))) * calc
	}
	return value
}
