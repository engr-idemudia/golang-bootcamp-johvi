package piscine

func Sqrt(nb int) int {
	count := 1
	for count*count <= nb { // for i := 1; i <= nb; i++
		if count*count == nb {
			return count
		}
		count++
	}
	return 0
}
