package main

import (
	"fmt"
	"piscine"
)

func main() {
	arg := 21
	fmt.Println(piscine.RecursiveFactorial(arg))
}
