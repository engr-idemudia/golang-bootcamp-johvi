package piscine

func Capitalize(s string) string {
	letters := []rune(s)
	vastus := ""
	if len(letters) <= 0 {
		return vastus
	}
	for i := 0; i < len(letters)-1; i++ {
		if letters[i+1] >= 'A' && letters[i+1] <= 'Z' {
			letters[i+1] = letters[i+1] + 32
		}
		if IsAlpha(string(letters[i])) == false {
			if letters[i+1] >= 'a' && letters[i+1] <= 'z' {
				letters[i+1] = letters[i+1] - 32
			}
		}
	}
	if letters[0] >= 'a' && letters[0] <= 'z' {
		letters[0] = letters[0] - 32
	}
	for i := 0; i < len(letters); i++ {
		vastus = vastus + string(letters[i])
	}
	return vastus
}
