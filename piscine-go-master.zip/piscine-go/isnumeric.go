package piscine

func IsNumeric(s string) bool {
	charOfstring := []rune(s)
	numbers := len(charOfstring)
	each := 0
	for _, digits := range charOfstring {
		if digits < 58 && digits > 47 {
			each++
		}
	}
	if each == numbers {
		return true
	} else {
		return false
	}
}
