package piscine

func BasicJoin(elems []string) string {
	ret := ""
	for _, str := range elems {
		ret += str
	}
	return ret
}
