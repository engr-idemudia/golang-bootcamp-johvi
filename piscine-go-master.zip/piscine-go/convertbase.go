package piscine

func ConvertBase(nbr, baseFrom, baseTo string) string {
	beginPt, endPT := 0, 0
	startSlice, endSlice := []rune(baseFrom), []rune(baseTo)
	for a := range startSlice {
		beginPt = a + 1
	}
	for a := range endSlice {
		endPT = a + 1
	}
	dt := 0
	toRune := []rune(nbr)
	for _, value := range toRune {
		for a, r := range startSlice {
			if value == r {
				dt = dt*beginPt + a
			}
		}
	}
	if dt == 0 {
		return string(endSlice[0])
	}
	baseStr := ""
	for dt > 0 {
		baseStr = string(endSlice[dt%endPT]) + baseStr
		dt = dt / endPT
	}
	return baseStr
}
