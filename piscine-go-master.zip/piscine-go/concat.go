package piscine

func Concat(str1 string, str2 string) string {
	Puttogether := str1 + str2
	return Puttogether
}
