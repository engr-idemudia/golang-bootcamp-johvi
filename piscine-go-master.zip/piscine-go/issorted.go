package piscine

func IsSorted(f func(a, b int) int, a []int) bool {
	result := true
	for i := 0; i < len(a); i++ {
		for j := i + 1; j < len(a); j++ {
			if a[0] > a[len(a)-1] {
				if f(a[j], a[i]) >= 0 {
					result = false
				}
			}
			if a[0] < a[len(a)-1] {
				if f(a[j], a[i]) <= 0 {
					result = false
				}
			}
		}
	}
	return result
}
