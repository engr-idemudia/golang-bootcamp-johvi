package main

import (
	"fmt"
	"os"

	"github.com/01-edu/z01"
)

func Order(runes []rune) {
	for i := 0; i < len(runes); i++ {
		for j := i + 1; j < len(runes); j++ {
			if runes[i] > runes[j] {
				z := runes[i]
				runes[i] = runes[j]
				runes[j] = z
			}
		}
	}
}

func main() {
	helptext := "--insert\n  -i\n\t This flag inserts the string into the string passed as argument.\n--order\n  -o\n\t This flag will behave like a boolean, if it is called it will order the argument."
	args := os.Args
	args = args[1:]
	str1 := ""
	str2 := ""
	len := len(args)
	lenarg := 0
	order := false
	if len == 0 {
		fmt.Println(helptext)
		return
	}
	for _, arg := range args {
		if arg == "--help" || arg == "-h" {
			fmt.Println(helptext)
			return
		}
		for j := range arg {
			lenarg = j + 1
		}
		if arg == "" {
			continue
		}
		if lenarg > 3 && arg[:3] == "-i=" {
			str1 = arg[3:]
			continue
		}
		if lenarg > 9 && arg[:9] == "--insert=" {
			str1 = arg[9:]
			continue
		}
		if arg == "--order" || arg == "-o" {
			order = true
			continue
		}
		str2 += arg
	}
	if order {
		s := []rune(str1 + str2)
		Order(s)
		for _, r := range s {
			z01.PrintRune(r)
		}
		z01.PrintRune('\n')
	} else {
		fmt.Println(str2 + str1)
	}
}
