package main

import (
	"fmt"
	"os"
)

func main() {
	fileName := os.Args[1:]
	aStr := 10
	myErr := false
	for i := 0; i < len(fileName); i++ {
		if fileName[0] == "-c" {
			runelist := []rune(fileName[1])
			aStr = RuneListToInt(runelist)
			fileName = fileName[2:]
		}
		fileIn := true
		file, err := os.Open(fileName[i])
		if err != nil {
			fileIn = false
			fmt.Print(err.Error())
			myErr = true
			fmt.Print(string('\n'))

		}
		if fileIn {
			if i > 0 {
				fmt.Print(string('\n'))
			}
			inside1 := "==> "
			inside2 := " <=="
			fmt.Print(inside1)
			fmt.Print(fileName[i])
			fmt.Print(inside2)
			fmt.Print(string('\n'))

			fileSt, err := file.Stat()
			if err != nil {
				fmt.Print("file size error")
			}
			txtlen := fileSt.Size()
			if int(txtlen) < aStr {
				aStr = int(txtlen)
			}
			data := make([]byte, txtlen)
			counter, err := file.Read(data)
			if err != nil {
				fmt.Print("Reading data error")
			}
			fmt.Print(string(data[counter-aStr:]))
		}
		file.Close()
	}
	if myErr {
		os.Exit(1)
	}
}

func RuneListToInt(list []rune) int {
	ans := 0
	calc := 1
	for i := 1; i < len(list); i++ {
		calc = calc * 10
	}
	for i := 0; i < len(list); i++ {
		ans = ans + int(list[i]-48)*calc
		calc /= 10
	}
	return ans
}
