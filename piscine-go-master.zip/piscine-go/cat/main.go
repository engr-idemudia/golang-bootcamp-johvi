package main

import (
	"io/ioutil"
	"os"

	"github.com/01-edu/z01"
)

func main() {
	if len(os.Args[1:]) == 0 {
		input, _ := ioutil.ReadAll(os.Stdin)
		for _, j := range string(input) {
			z01.PrintRune(j)
		}
		return
	}
	if len(os.Args) >= 2 {
		for _, v := range os.Args[1:] {
			file, err := os.Open(v)
			if err != nil {
				str := "ERROR: "
				for _, v := range str {
					z01.PrintRune(rune(v))
				}
				for _, v := range err.Error() {
					z01.PrintRune(rune(v))
				}
				z01.PrintRune('\n')
				os.Exit(1)
			}
			r, _ := ioutil.ReadAll(file)
			if len(r) != 0 {
				for _, v := range string(r) {
					z01.PrintRune(rune(v))
				}
			}
			file.Close()
		}
	}
}
