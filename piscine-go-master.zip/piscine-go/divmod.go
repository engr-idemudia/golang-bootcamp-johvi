package piscine

// result := 0

func DivMod(a int, b int, div *int, mod *int) {
	// int result := a / b
	intDivision := a / b
	modDivision := a % b

	*div = intDivision

	*mod = modDivision
}
