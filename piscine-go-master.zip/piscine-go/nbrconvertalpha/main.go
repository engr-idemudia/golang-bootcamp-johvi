package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	isArgs := os.Args
	eachArgs := isArgs[1:]
	if len(eachArgs) == 0 {
		return
	}
	isUpper := false
	if eachArgs[0] == "--upper" {
		isUpper = true
		eachArgs = eachArgs[1:]
	}
	slice := []int{}
	for _, argsPass := range eachArgs {
		results := 0
		for _, letter := range argsPass {
			if !('0' <= letter && letter <= '9') {
				results = -1
				break
			}
			results = results * 10
			results = results + int(letter) - '0'
		}
		slice = append(slice, results)
	}
	for _, item := range slice {
		if 1 <= item && item <= 26 {
			if isUpper {
				z01.PrintRune('A' + rune(item) - 1)
			} else {
				z01.PrintRune('a' + rune(item) - 1)
			}
		} else {
			z01.PrintRune(' ')
		}
	}
	z01.PrintRune('\n')
}
