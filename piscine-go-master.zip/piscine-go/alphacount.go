package piscine

func AlphaCount(s string) int {
	sr := []rune(s)
	count := 0
	for i := 0; i < len(sr); i++ {
		if (sr[i] < 91 && sr[i] > 64) || (sr[i]) > 96 && sr[i] < 123 {
			count++
		}
	}
	return count
}
