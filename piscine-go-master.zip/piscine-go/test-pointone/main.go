package main

import (
	"fmt"
	"piscine"
)

func main() {
	n := 0
	piscine.PointOne(&n)
	fmt.Println(n)

	fmt.Printf("This is the address : %v", &n)
	fmt.Println()
}
