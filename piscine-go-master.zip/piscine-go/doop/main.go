package main

import (
	"os"
)

func main() {
	result := 0
	arguments := os.Args[1:]
	if len(arguments) > 3 || len(arguments) < 3 {
		return
	}
	arrayOfFunction := []func(int, int) int{add, sub, div, mult, mod}
	a := arguments[0]
	b := arguments[2]

	if a[0] == '-' {
		a = a[1:]
		if !IsNumeric(a) {
			return
		}
	} else {
		if !IsNumeric(a) {
			return
		}
	}

	if b[0] == '-' {
		b = b[1:]
		if !IsNumeric(b) {
			return
		}
	} else {
		if !IsNumeric(b) {
			return
		}
	}

	nbr1 := Atoi(arguments[0])
	nbr2 := Atoi(arguments[2])

	if nbr1 >= 9223372036854775807 || nbr1 <= -9223372036854775807 {
		return
	}
	if nbr2 >= 9223372036854775807 || nbr2 <= -9223372036854775807 {
		return
	}

	if len(arguments) == 3 {
		if arguments[1] == "+" {
			result = applyFunction(arrayOfFunction[0], nbr1, nbr2)
			if result >= 9223372036854775807 || result <= -9223372036854775807 {
				return
			} else {
				os.Stdout.WriteString(iota(result))
				os.Stdout.WriteString("\n")
			}
		}
		if arguments[1] == "-" {
			result = applyFunction(arrayOfFunction[1], nbr1, nbr2)
			if result >= 9223372036854775807 || result <= -9223372036854775807 {
				return
			} else {
				os.Stdout.WriteString(iota(result))
				os.Stdout.WriteString("\n")
			}
		}
		if arguments[1] == "/" {
			if arguments[2] == "0" {
				os.Stdout.WriteString("No division by 0")
				os.Stdout.WriteString("\n")
			} else {
				result = applyFunction(arrayOfFunction[2], nbr1, nbr2)
				if result >= 9223372036854775807 || result <= -9223372036854775807 {
					return
				} else {
					os.Stdout.WriteString(iota(result))
					os.Stdout.WriteString("\n")
				}
			}
		}
		if arguments[1] == "*" {
			result = applyFunction(arrayOfFunction[3], nbr1, nbr2)
			if result >= 9223372036854775807 || result <= -9223372036854775807 {
				return
			} else {
				os.Stdout.WriteString(iota(result))
				os.Stdout.WriteString("\n")
			}
		}
		if arguments[1] == "%" {
			if arguments[2] == "0" {
				os.Stdout.WriteString("No modulo by 0")
				os.Stdout.WriteString("\n")
			} else {
				result = applyFunction(arrayOfFunction[4], nbr1, nbr2)
				if result >= 9223372036854775807 || result <= -9223372036854775807 {
					return
				} else {
					os.Stdout.WriteString(iota(result))
					os.Stdout.WriteString("\n")
				}
			}
		}
	}
}

func IsDigits(s string) bool {
	for _, c := range s {
		if c < '0' || c > '9' {
			return false
		}
	}
	return true
}

func Atoi(s string) int {
	if s == "" {
		return 0
	}
	sign := 1
	res := 0
	if s[0] == '-' {
		sign = -1
		s = s[1:]
	} else if s[0] == '+' {
		s = s[1:]
	}
	if len(s) == 0 {
		return 0
	}

	if !IsDigits(s) {
		return 0
	} else {
		for j := 0; j < len(s); j++ {
			res = +res*10 + int(s[j]-'0')
		}
	}
	return res * sign
}

func IsNumeric(s string) bool {
	a := []rune(s)
	for i := 0; i < len(a); i++ {
		if a[i] > 57 || a[i] < 48 {
			return false
		}
	}
	return true
}

func iota(n int) (s string) {
	prefix := ""
	if n == 0 {
		return "0"
	}
	for m := n; m != 0; m /= 10 {
		dig := m % 10
		if dig < 0 {
			prefix = "-"
			dig *= -1
		}
		s = string(rune(dig)+'0') + s
	}
	return prefix + s
}

func add(a, b int) int {
	return a + b
}

func sub(a, b int) int {
	return a - b
}

func div(a, b int) int {
	return a / b
}

func mult(a, b int) int {
	return a * b
}

func mod(a, b int) int {
	return a % b
}

func applyFunction(f func(int, int) int, a int, b int) int {
	apply := f(a, b)
	return apply
}
