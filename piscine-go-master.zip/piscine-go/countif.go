package piscine

func CountIf(f func(string) bool, tab []string) int {
	counter := 0
	for i := 0; i < len(tab); i++ { // for _, value := range tab {
		if f(tab[i]) { // if f(value) {
			counter++
		}
	}
	return counter
}
