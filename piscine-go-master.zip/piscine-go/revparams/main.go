package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	receivedArgs := os.Args[1:]
	for i := len(receivedArgs) - 1; i >= 0; i-- {
		thewords := receivedArgs[i]
		for j := 0; j < len(thewords); j++ {
			z01.PrintRune(rune(thewords[j]))
		}
		z01.PrintRune('\n')
	}
}
