package piscine

func StrLen(word string) int {
	count := []rune(word)
	return len(count)
}
