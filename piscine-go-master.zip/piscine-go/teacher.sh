INTERVIEW=$(head -n 179 ./streets/Buckingham_Place | tail -n 1 | sed "s/SEE INTERVIEW #//1")
echo $INTERVIEW

cat ./interviews/interview-"$INTERVIEW"
grep -A4 L337 ./vehicles | grep -B1 -A3 Honda | grep -B2 -A2 Blue | grep -B4 "Height: 6'" 

cat ./memberships/AAA ./memberships/Delta_SkyMiles ./memberships/Museum_of_Bash_History ./memberships/Terminal_City_Library | grep "$MAIN_SUSPECT" | wc -l