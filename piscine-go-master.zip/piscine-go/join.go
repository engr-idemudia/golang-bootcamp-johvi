package piscine

func Join(strs []string, sep string) string {
	seperate := false
	ret := ""
	for _, str := range strs {
		if seperate {
			ret += sep
		} else {
			seperate = true
		}
		ret += str

	}
	return ret
}
