package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	receivedArgs := os.Args[1:]
	for i := 0; i < len(receivedArgs); i++ {
		myword := receivedArgs[i]
		// fmt.Println("my word is ", myword)
		for j := 0; j < len(myword); j++ {
			z01.PrintRune(rune(myword[j]))
		}
		z01.PrintRune('\n')
	}
}
