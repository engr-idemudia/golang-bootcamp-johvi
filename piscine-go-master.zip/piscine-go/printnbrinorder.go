package piscine

import "github.com/01-edu/z01"

func PrintNbrInOrder(n int) {
	if n < 0 {
		return
	}
	slice := slice(n)
	SortIntegerTable(slice)
	if n == 0 {
		z01.PrintRune('0')
	}
	for i := 0; i < len(slice); i++ {
		z01.PrintRune(rune(slice[i]) + 48)
	}
}

func slice(n int) []int {
	var ret []int
	for n != 0 {
		ret = append(ret, n%10)
		n /= 10
	}
	return ret
}
