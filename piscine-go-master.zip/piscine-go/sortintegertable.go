package piscine

// import (
// 	"sort"
// )

// func SortIntegerTable(table []int) {
// 	sort.Slice(table, func(i, j int) bool {
// 		return table[i] < table[j]
// 	})
// }

func SortIntegerTable(table []int) {
	for i := 0; i < len(table)-1; i++ {
		sort(table)
	}
}

func sort(table []int) {
	for i := 0; i < len(table)-1; i++ {
		if table[i] > table[i+1] {
			// a := table[i]
			// b := table[i+1]
			// c := a
			// table[i] = b
			// table[i+1] = c
			// above 5 lines are redundant
			a := table[i+1]
			table[i+1] = table[i]
			table[i] = a

		}
	}
}
