package piscine

import "github.com/01-edu/z01"

func valid(nums [8]int, n int) bool {
	for i := 0; i < n; i++ {
		diff := nums[n] - nums[i]
		if diff < 0 {
			diff = diff * (-1)
		}
		if nums[i] == nums[n] || diff == n-i {
			return false
		}
	}
	return true
}

func dfs(nums [8]int, index int) {
	if index == 8 {
		var char rune
		for i := 0; i < 8; i++ {
			char = '0'
			for j := 0; j < nums[i]; j++ {
				char++
			}
			z01.PrintRune(char)
		}
		z01.PrintRune(10)
		return
	}
	for i := 1; i < 9; i++ {
		nums[index] = i
		if valid(nums, index) {
			dfs(nums, index+1)
		}
	}
}

func EightQueens() {
	var nums [8]int
	dfs(nums, 0)
}
