package piscine

func Any(f func(string) bool, a []string) bool {
	for _, value := range a { // for i:=0; i<len(a)-1;i++{
		if f(value) { // if f(a[i]) {
			return true
		}
	}
	return false
}
