package piscine

func AppendRange(min, max int) []int {
	var btw []int
	for j := min; j < max; j++ {
		btw = append(btw, j)
	}
	return btw
}
