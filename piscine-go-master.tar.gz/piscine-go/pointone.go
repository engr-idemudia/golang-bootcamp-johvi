package piscine

func PointOne(n *int) {
	//*n = *n + 1
	*n += 1
}
