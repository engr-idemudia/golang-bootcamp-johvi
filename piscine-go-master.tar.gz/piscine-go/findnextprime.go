package piscine

func FindNextPrime(nb int) int {
	if nb <= 2 {
		return 2
	}
	if nb%2 == 0 {
		nb++
	}
	opt := newPrime(nb)
	for !(opt) {
		nb = nb + 2
		opt = newPrime(nb)
	}
	return nb
}

func newPrime(nb int) bool {
	if nb == 2 {
		return true
	}
	counter := 0
	for i := 3; i < nb; i = i + 2 {
		if nb%i == 0 {
			counter++
		}
	}
	if counter == 0 {
		return true
	} else {
		return false
	}
}
