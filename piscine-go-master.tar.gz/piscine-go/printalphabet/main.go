package main

import (
	"github.com/01-edu/z01"
)

func main() {
	i := 'a'
	for i <= 'z' {
		z01.PrintRune(i)
		i++
	}
	z01.PrintRune('\n')

	// print in reverse order

	// j := 'z'
	// for j >= 'a' {
	// 	z01.PrintRune(j)
	// 	j--
	// }
	// z01.PrintRune('\n')
}
