package piscine

func UltimateDivMod(a *int, b *int) {
	intDiv := *a / *b
	remainder := *a % *b

	*a = intDiv
	*b = remainder
}
