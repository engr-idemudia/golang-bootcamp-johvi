package piscine

func IsUpper(s string) bool {
	charOfstring := []rune(s)
	letters := len(charOfstring)
	each := 0
	for _, upper := range charOfstring {
		if upper < 91 && upper > 64 {
			each++
		}
	}
	if each == letters {
		return true
	} else {
		return false
	}
}
