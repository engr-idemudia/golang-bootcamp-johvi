package piscine

func TrimAtoi(word string) int {
	if len(word) <= 0 {
		return 0
	}
	multiplier := 1
	answer := 0
	for _, letter := range word {
		if letter >= '0' && letter <= '9' {
			extranumer := int(letter - '0')
			answer = answer*10 + extranumer
		} else if letter == '-' && answer == 0 {
			multiplier = -1
		}
	}
	return answer * multiplier
}
