package piscine

func IsLower(s string) bool {
	charOfstring := []rune(s)
	letters := len(charOfstring)
	each := 0
	for _, lower := range charOfstring {
		if lower < 123 && lower > 96 {
			each++
		}
	}
	if each == letters {
		return true
	} else {
		return false
	}
}
