package main

import "piscine"

func main() {
	piscine.PrintStr("Hello World!")
}
