package piscine

func ToUpper(s string) string {
	toRunes := []rune(s)
	word := len(s) - 1
	for i := 0; i <= word; i++ {
		if toRunes[i] > 96 && toRunes[i] < 123 {
			toRunes[i] -= 32
		}
	}
	return string(toRunes)
}
