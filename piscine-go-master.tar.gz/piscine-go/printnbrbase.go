package piscine

import "github.com/01-edu/z01"

func PrintNbrBase(nbr int, base string) {
	counter := 0
	for _, char := range base {
		isSame := 0
		if char == '+' || char == '-' {
			z01.PrintRune('N')
			z01.PrintRune('V')
			return
		}
		for _, char2 := range base {
			if char == char2 {
				isSame++
			}
			if isSame >= 2 {
				z01.PrintRune('N')
				z01.PrintRune('V')
				return
			}
		}
		counter++
	}
	if counter < 2 {
		z01.PrintRune('N')
		z01.PrintRune('V')
		return
	}
	result := ""
	a := []rune(base)
	if nbr < 0 {
		z01.PrintRune('-')
	}
	for ; nbr != 0; nbr /= counter {
		index := nbr % counter
		if index < 0 {
			index = -index
		}
		result = string(a[index]) + result
	}
	for _, r := range result {
		z01.PrintRune(r)
	}
}
