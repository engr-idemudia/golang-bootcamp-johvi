package piscine

func SplitWhiteSpaces(s string) []string {
	var source []string
	var eachElement string
	runes := []rune(s)
	for i := 0; i < len(s); i++ {
		if runes[i] == ' ' || runes[i] == '\t' || runes[i] == '\n' {
			if len(eachElement) != 0 {
				source = append(source, eachElement)
			}
			eachElement = ""
		} else {
			eachElement += string(runes[i])
		}
	}
	source = append(source, eachElement)
	return source
}
