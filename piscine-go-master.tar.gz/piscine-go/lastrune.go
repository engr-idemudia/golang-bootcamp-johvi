package piscine

func LastRune(s string) rune {
	x := []rune(s)            // turns the string given into an array of runes
	Lastletter := x[len(x)-1] // taking length of array of x - 1
	return Lastletter
}
