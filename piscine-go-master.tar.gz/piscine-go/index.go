package piscine

func Index(s string, toFind string) int {
	parent := []rune(s)
	child := []rune(toFind)
	x := len(parent)
	y := len(child)
	if y == 0 {
		return 0
	}

	for index, letters := range parent {
		if letters == child[0] && x >= y+index-1 {
			run := 1
			for i := 1; i < y; i++ {
				if child[i] == parent[index+i] {
					run++
				}
			}
			if run == y {
				return index
			}
		}
	}
	return -1
}
