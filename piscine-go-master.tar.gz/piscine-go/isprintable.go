package piscine

func IsPrintable(s string) bool {
	for _, print := range s {
		if rune(print) < 32 || rune(print) > 126 {
			return false
		}
	}
	return true
}
