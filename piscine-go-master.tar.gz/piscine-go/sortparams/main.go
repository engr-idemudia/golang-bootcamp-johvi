package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	arguments := os.Args
	for i := 1; i < len(arguments); i++ {
		for j := i + 1; j < len(arguments); j++ {
			if os.Args[i] > os.Args[j] {
				z := os.Args[i]
				os.Args[i] = os.Args[j]
				os.Args[j] = z
			}
		}
		a := []rune(os.Args[i])
		for k := 0; k < len(a); k++ {
			z01.PrintRune(a[k])
		}
		z01.PrintRune('\n')
	}
}
