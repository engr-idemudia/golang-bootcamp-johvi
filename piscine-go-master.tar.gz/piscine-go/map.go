package piscine

func Map(f func(int) bool, a []int) []bool {
	var answer []bool
	for _, value := range a {
		answer = append(answer, f(value))
	}
	return answer
}
