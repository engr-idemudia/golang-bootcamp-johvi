package piscine

func SortWordArr(a []string) {
	for i := 0; i <= len(a); i++ {
		for j := i + 1; j <= len(a)-1; j++ {
			if a[i] > a[j] {
				a[i], a[j] = a[j], a[i]
			}
		}
	}
}
