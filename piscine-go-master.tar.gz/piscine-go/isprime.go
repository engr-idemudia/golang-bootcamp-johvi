package piscine

func IsPrime(nb int) bool {
	if nb <= 1 {
		return false
	}
	counter := 0
	for i := 2; i < nb; i++ {
		if nb%i == 0 {
			counter++
		}
	}
	if counter == 0 {
		return true
	} else {
		return false
	}
}
