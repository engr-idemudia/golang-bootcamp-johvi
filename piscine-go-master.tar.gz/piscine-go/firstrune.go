package piscine

func FirstRune(s string) rune {
	a := []rune(s) // {H, e, l, l, o, !}
	return a[0]
}

// var a string = "Hello!"
// 	for i := 0; i < len(a); i++ {
// 		z01.PrintRune(rune(a[i]))
// 	}
