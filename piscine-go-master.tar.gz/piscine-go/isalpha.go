package piscine

func IsAlpha(s string) bool {
	aString := []rune(s)
	value := true
	word := 0

	for i := range aString {
		word = i
	}

	for i := 0; i <= word; i++ {
		if (aString[i] < 'A' || aString[i] > 'Z') &&
			(aString[i] < 'a' || aString[i] > 'z') &&
			(aString[i] < '0' || aString[i] > '9') {
			value = false
			break
		}
	}
	return value
}
