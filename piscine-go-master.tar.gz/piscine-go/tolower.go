package piscine

func ToLower(s string) string {
	toRunes := []rune(s)
	word := len(s) - 1
	for i := 0; i <= word; i++ {
		if toRunes[i] > 64 && toRunes[i] < 91 {
			toRunes[i] += 32
		}
	}
	return string(toRunes)
}
