package main

import "piscine"

func main() {
	piscine.PrintCombN(1)
	piscine.PrintCombN(3)
	piscine.PrintCombN(9)
}
