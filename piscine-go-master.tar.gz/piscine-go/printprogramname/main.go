package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	programName := os.Args[0]
	astr := []rune(programName)
	for i := 0; i < len(astr); i++ {
		if astr[i] < 46 || astr[i] > 47 {
			z01.PrintRune(astr[i])
		}
	}
	z01.PrintRune('\n')
}
