package main

import "piscine"

func main() {
	piscine.PrintComb2()
}
