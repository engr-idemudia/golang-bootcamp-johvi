package piscine

func ConcatParams(args []string) string {
	var lengthOfString string
	for i := 0; i < len(args); i++ {
		lengthOfString += args[i] // by default a string initializes to nil
		if i < len(args)-1 {
			lengthOfString += "\n"
		}
	}
	return lengthOfString
}
