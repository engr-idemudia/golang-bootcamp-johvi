package piscine

import (
	"github.com/01-edu/z01"
)

func PrintStr(s string) {
	slicechar := []byte(s)
	// 	// slicechar[0] = 'H'

	for _, word := range slicechar {
		z01.PrintRune(rune(word))

		// z01.PrintRune(slicechar)

		// fmt.Printf("%v, %v\n", index, word) // by using the fmt package
		// fmt.Println(slicechar)
	}
	// z01.PrintRune('\n')
}
