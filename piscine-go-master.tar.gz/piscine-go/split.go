package piscine

func Split(s, sep string) []string {
	var result []string
	check := false
	for !check {
		number := Index(s, sep)
		if number > 0 {
			result = append(result, s[0:number])
			s = s[number+len(sep):]
		}
		if number <= 0 {
			check = true
		}
	}
	result = append(result, s)
	return result
}
