package main

import (
	"fmt"
	"os"
)

func main() {
	file, _ := os.Open("quest8.txt")
	if len(os.Args) < 2 {
		fmt.Println("File name missing")
	}
	if len(os.Args) > 2 {
		fmt.Println("Too many arguments")
	}
	if len(os.Args) == 2 {
		arr := make([]byte, 14)
		file.Read(arr)
		fmt.Println(string(arr))
		file.Close()
	}
}
